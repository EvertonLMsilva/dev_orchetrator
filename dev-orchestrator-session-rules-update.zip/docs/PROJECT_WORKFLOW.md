# Workflow

## Estados de task

``` text
PLANNED
  ↓
READY_FOR_ANALYSIS
  ↓
ANALYZING
  ├─→ BLOCKED
  ├─→ NEEDS_APPROVAL
  └─→ READY_FOR_CODEX
          ↓
      IN_PROGRESS
       ├─→ BLOCKED
       ├─→ FAILED
       └─→ DONE
```

`CANCELLED` encerra quando permitido pela política.

## Ciclo

1.  selecionar menor task desbloqueada;
2.  Planner decide se possui evidência suficiente;
3.  se não, produz `BOT_COMMAND`;
4.  agente local executa e retorna `BOT_RESULT`;
5.  Planner refina/fecha task;
6.  task vira `READY_FOR_CODEX`;
7.  abrir nova ExecutorSession para essa task;
8.  Executor implementa/testa;
9.  retorna `CODEX_RESULT`;
10. Planner revisa;
11. DONE, correção atômica ou BLOCKED;
12. informar Discord;
13. encerrar ExecutorSession ao concluir/falhar/cancelar;
14. próxima task usa nova ExecutorSession.

## BLOCKED do Executor

Se o bloqueio for uma decisão pequena da mesma task: - Planner
resolve; - mesma ExecutorSession pode continuar.

Se o bloqueio alterar arquitetura/escopo substancialmente: - parar; -
refinar a task; - decidir explicitamente se a execução anterior deve ser
encerrada.

## Rotação do Planner

PlannerSession pode continuar enquanto econômica.

Quando `contextBudget` configurado for atingido, ou quando o contexto
deixar de ser econômico:

1.  gerar `PLANNER_HANDOFF`;
2.  persistir estado necessário;
3.  emitir `SESSION_CLOSED`;
4.  iniciar nova PlannerSession;
5.  carregar handoff + estado canônico mínimo;
6.  emitir `SESSION_STARTED`;
7.  continuar de `nextAction`.

Não copiar a conversa inteira.

## Escalonar ao humano

-   decisão de produto;
-   operação de risco;
-   custo acima do budget;
-   conflito arquitetural sem decisão registrada;
-   loop/retry excedido;
-   segredo/permissão necessária.

## Validação

Teste focado → integração próxima quando necessária → suíte ampla
somente em gate/mudança transversal.
