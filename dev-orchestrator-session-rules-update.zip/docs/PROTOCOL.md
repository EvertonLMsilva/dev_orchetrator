# Protocolo

Todo envelope possui:

``` text
protocolVersion
messageType
messageId
correlationId
projectId
taskId?
sessionId?
createdAt
payload
```

## Tipos principais

### BOT_COMMAND

Planner solicita ação local permitida.

### BOT_RESULT

Retorna `SUCCESS | FAILED | DENIED`, exitCode, output limitado e
indicação de truncamento.

### PLANNER_DECISION

`INVESTIGATE | READY_FOR_CODEX | DONE | BLOCKED | NEEDS_APPROVAL | HANDOFF`.

### CODEX_TASK

Referência da task fechada, escopo, arquivos permitidos, testes e
restrições.

### CODEX_RESULT

`DONE | BLOCKED | FAILED`, arquivos alterados, testes e evidência
mínima.

### APPROVAL_REQUEST / APPROVAL_RESULT

Decisão humana exigida pela política.

## Sessões

### SESSION_STARTED

``` json
{
  "sessionType": "PLANNER|EXECUTOR",
  "sessionId": "...",
  "reason": "NEW_TASK|HANDOFF|INITIAL"
}
```

### SESSION_CLOSED

``` json
{
  "sessionType": "PLANNER|EXECUTOR",
  "sessionId": "...",
  "reason": "DONE|FAILED|CANCELLED|CONTEXT_BUDGET|REPLACED"
}
```

### PLANNER_HANDOFF

``` json
{
  "projectId": "...",
  "currentTask": "...",
  "taskStatus": "...",
  "decisions": [],
  "evidence": [],
  "completed": [],
  "blocked": [],
  "nextAction": "..."
}
```

Regras: - somente decisões/evidências ainda relevantes; - `completed`
usa IDs/referências, não histórico completo; - handoff não substitui
estado canônico; - nova sessão pode validar/restaurar o estado antes de
continuar.

## Regras gerais

-   respostas correlacionam com `correlationId`;
-   eventos de sessão usam `sessionId`;
-   resultado atrasado de tentativa/sessão antiga não altera estado
    atual sem validação;
-   payloads são validados por schema;
-   output grande é limitado/referenciado;
-   Discord não substitui persistência.
