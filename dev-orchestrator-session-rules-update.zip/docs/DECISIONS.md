# Decisões duráveis

-   O Dev Orchestrator é projeto separado do MKTauto.
-   Discord é interface e transporte, não source of truth.
-   Estado de projects/tasks/execuções é persistido pelo
    Orchestrator/repositório.
-   Planner e Executor são papéis separados.
-   ChatGPT/Planner concentra análise, arquitetura e especificação.
-   Codex/Executor recebe somente task fechada.
-   Agente local executa comandos controlados no PC e devolve evidência.
-   TDD e tasks atômicas são padrão.
-   Segurança usa allowlist, sandbox de paths e approval gates.
-   Autonomia aumenta somente após o ciclo controlado estar comprovado.
-   Ports/adapters permitem trocar Planner, Executor e agente.
-   Arquitetura modular-first; microserviços somente com justificativa
    operacional.
-   MVP termina em P5.
-   Integrações concretas de ChatGPT/OpenAI e Codex serão verificadas
    contra interfaces oficiais atuais antes de implementação.

## Sessões e contexto

-   `PlannerSession != ProjectState`.
-   `ExecutorSession != TaskState`.
-   Sessões são descartáveis; estado persistente nunca depende da
    memória de uma sessão.
-   Uma task atômica do Executor/Codex usa uma sessão própria.
-   Ao iniciar uma nova task, iniciar nova `ExecutorSession`.
-   Um `BLOCKED` simples da mesma task pode continuar na mesma
    `ExecutorSession`.
-   Ao `DONE`, `FAILED` ou `CANCELLED`, a `ExecutorSession` é encerrada.
-   Nova sessão do Executor recebe tudo que precisa via task/estado
    persistente; não depende da sessão anterior.
-   Planner pode reutilizar sua sessão enquanto ela permanecer
    econômica.
-   Planner possui `contextBudget` configurável. Não existe percentual
    fixo de domínio.
-   Ao atingir o budget ou quando o contexto deixar de ser econômico, o
    Planner produz `PLANNER_HANDOFF`, encerra a sessão e continua em
    nova sessão.
-   O handoff contém somente estado necessário para continuar, não
    transcrição completa.
