# Arquitetura

## Estilo

Modular-first, ports/adapters. Microserviços não são requisito.

## Núcleo

``` text
DiscordGateway
      ↓
Orchestrator/Application
 ├─ ProjectRegistry
 ├─ TaskRepository
 ├─ WorkflowEngine
 ├─ ApprovalPolicy
 ├─ AuditRepository
 ├─ SessionCoordinator
 ├─ PlannerPort ─────→ PlannerAdapter
 ├─ ExecutorPort ────→ CodexAdapter
 └─ LocalAgentPort ──→ LocalAgentAdapter
```

## Portas

### PlannerPort

Recebe contexto mínimo estruturado e retorna decisão estruturada:
investigar, preparar execução, concluir, bloquear, fazer handoff ou
pedir aprovação.

### ExecutorPort

Recebe `CODEX_TASK` fechada e retorna `CODEX_RESULT`.

### LocalAgentPort

Executa ação previamente validada pela política dentro do workspace do
projeto.

### TaskRepository

Persiste task, estado, dependências e evidências necessárias.

### ProjectRegistry

Mapeia `projectId` para workspace, políticas e configuração permitida.

### AuditRepository

Registra eventos relevantes com correlation IDs, sem segredos.

## Sessões

### PlannerSession

Contexto temporário usado pelo Planner. Pode abranger várias
interações/tasks enquanto permanecer dentro do `contextBudget`.

Não contém estado canônico do projeto.

### ExecutorSession

Contexto temporário dedicado a uma task atômica. Uma nova task cria uma
nova sessão.

Um `BLOCKED` simples da mesma task pode continuar na mesma sessão.
`DONE`, `FAILED` e `CANCELLED` encerram a sessão.

### SessionCoordinator

Responsável futuramente por: - identificar sessão ativa; - aplicar
context budget; - iniciar/encerrar sessões; - solicitar/restaurar
handoff; - impedir dependência de memória descartável.

A implementação concreta depende das interfaces oficiais escolhidas em
P3/P4.

## Planner Handoff

Formato mínimo conceitual:

``` text
projectId
currentTask
taskStatus
decisions[]
evidence[]
completed[]
blocked[]
nextAction
```

`completed` contém IDs relevantes, não histórico completo.

## Fonte de verdade

Discord, PlannerSession e ExecutorSession são interfaces/contextos
temporários.

Estado canônico pertence ao Orchestrator/repositório: Projects, Tasks,
estados, decisões duráveis, evidências necessárias e audit trail.

## Integrações externas

A forma concreta de integrar ChatGPT/OpenAI e Codex não é presumida. P3
e P4 verificam interfaces oficiais atuais antes dos adapters.

## Invariantes

-   Executor não decide arquitetura.
-   Planner não executa shell diretamente.
-   Agente local não escolhe comandos por conta própria.
-   Toda execução pertence a projeto/task/correlation ID.
-   Task só chega ao Executor em `READY_FOR_CODEX`.
-   Sessão descartada não pode causar perda de estado do projeto/task.
