# Atualização --- regras de sessões e contexto

Sobrescreva no projeto somente os arquivos presentes neste pacote,
preservando os caminhos.

Arquivos atualizados: - `docs/DECISIONS.md` - `docs/ARCHITECTURE.md` -
`docs/PROJECT_WORKFLOW.md` - `docs/PROTOCOL.md` - `docs/tasks/P3.md` -
`docs/tasks/P4.md` - `docs/tasks/P9.md`

Não apague nem altere outros documentos.

Principais decisões: - sessão não é estado persistente; - uma task
atômica concluída usa uma sessão Codex própria; - `BLOCKED` pequeno da
mesma task continua na mesma sessão; - Planner gira de sessão por
`contextBudget` configurável; - troca do Planner usa `PLANNER_HANDOFF`
estruturado.
